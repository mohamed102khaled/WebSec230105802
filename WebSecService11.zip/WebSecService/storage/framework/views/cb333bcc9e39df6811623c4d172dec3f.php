
<?php $__env->startSection('title', 'Edit User'); ?>
<?php $__env->startSection('content'); ?>

<div class="container mt-5">
    <h2>Edit User</h2>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('users_save', $user->id ?? '')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="form-group mb-2">
            <label class="form-label">Name:</label>
            <input type="text" class="form-control" name="name" value="<?php echo e(old('name', $user->name ?? '')); ?>" required>
        </div>

        <div class="form-group mb-2">
            <label class="form-label">Email:</label>
            <input type="email" class="form-control" name="email" value="<?php echo e(old('email', $user->email ?? '')); ?>" required>
        </div>

        
        <div class="form-group mb-2">
            <label class="form-label">Current Role:</label>
            <input type="text" class="form-control" value="<?php echo e(ucfirst($user->roles->first()->name ?? 'User')); ?>" disabled>
            <input type="hidden" name="role" value="<?php echo e($user->roles->first()->name ?? 'user'); ?>">
        </div>

        <div class="form-group mb-2">
            <label class="form-label">Security Question:</label>
            <select name="security_question" class="form-control">
                <option value="">-- Select a Security Question --</option>
                <option value="What is your pet's name?" <?php echo e(old('security_question', $user->security_question ?? '') == "What is your pet's name?" ? 'selected' : ''); ?>>What is your pet's name?</option>
                <option value="What is your mother's maiden name?" <?php echo e(old('security_question', $user->security_question ?? '') == "What is your mother's maiden name?" ? 'selected' : ''); ?>>What is your mother's maiden name?</option>
                <option value="What city were you born in?" <?php echo e(old('security_question', $user->security_question ?? '') == "What city were you born in?" ? 'selected' : ''); ?>>What city were you born in?</option>
            </select>
        </div>

        <div class="form-group mb-2">
            <label class="form-label">Security Answer:</label>
            <input type="text" class="form-control" name="security_answer" placeholder="Enter new answer or leave blank to keep current">
        </div>

        <div class="form-group mb-2">
            <label class="form-label">New Password (leave empty to keep current password):</label>
            <input type="password" class="form-control" name="password">
        </div>

        <div class="form-group mb-2">
            <label class="form-label">Confirm New Password:</label>
            <input type="password" class="form-control" name="password_confirmation">
        </div>

        
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_users')): ?>
        <div class="form-group mb-2">
            <label class="form-label">Edit Role:</label>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_users')): ?>
                <select name="role" class="form-select">
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($role->name); ?>" <?php echo e($user->hasRole($role->name) ? 'selected' : ''); ?>>
                            <?php echo e(ucfirst($role->name)); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            <?php else: ?>
                <input type="text" class="form-control" value="<?php echo e(ucfirst($user->role ?? 'User')); ?>" disabled>
                <input type="hidden" name="role" value="<?php echo e($user->role ?? 'user'); ?>">
            <?php endif; ?>
        </div>


        <div class="form-group mb-2">
            <label class="form-label">Permissions:</label>
            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-check">
                    <input type="checkbox" name="permissions[]" value="<?php echo e($permission->name); ?>" class="form-check-input"
                        <?php echo e($user->hasPermissionTo($permission->name) ? 'checked' : ''); ?>>
                    <label class="form-check-label"><?php echo e($permission->name); ?></label>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>

        <button type="submit" class="btn btn-primary">Save Changes</button>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\WebSec230105802\WebSecService\resources\views/users/edit.blade.php ENDPATH**/ ?>