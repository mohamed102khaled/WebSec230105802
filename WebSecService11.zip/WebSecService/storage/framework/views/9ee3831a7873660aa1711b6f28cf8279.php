
<?php $__env->startSection('title', 'Users Management'); ?>
<?php $__env->startSection('content'); ?>



<div class="row mb-3">
    <div class="col col-10">
        <h1>Users</h1>
    </div>
    <div class="col col-2">
        <a href="<?php echo e(route('users_add')); ?>" class="btn btn-success form-control">Add User</a>
    </div>
</div>

<div class="container mt-4">
    <form method="GET" action="<?php echo e(route('users_list')); ?>">
        <div class="row mb-3">
            <div class="col col-sm-3">
                <input name="keywords" type="text" class="form-control" placeholder="Search by Name or Email" value="<?php echo e(request()->keywords); ?>" />
            </div>
            <div class="col col-sm-2">
                <select name="role" class="form-select">
                    <option value="" <?php echo e(request()->role == "" ? "selected" : ""); ?> disabled>Filter by Role</option>
                    <option value="admin" <?php echo e(request()->role == "admin" ? "selected" : ""); ?>>Admin</option>
                    <option value="user" <?php echo e(request()->role == "user" ? "selected" : ""); ?>>User</option>
                    <option value="Employee" <?php echo e(request()->role == "Employee" ? "selected" : ""); ?>>Employee</option>
                </select>
            </div>
            <div class="col col-sm-2">
                <button type="submit" class="btn btn-primary">Filter</button>
            </div>
            <div class="col col-sm-2">
                <a href="<?php echo e(route('users_list')); ?>" class="btn btn-danger">Reset</a>
            </div>
        </div>
    </form>
</div>


<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card mt-4">
        <div class="card-body">
            <h3><?php echo e($user->name); ?></h3>
            <table class="table table-striped">
                <tr><th width="20%">Name</th><td><?php echo e($user->name); ?></td></tr>
                <tr><th>Email</th><td><?php echo e($user->email); ?></td></tr>
                <tr><th>Role</th><td><?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <span class="badge bg-primary"><?php echo e($role->name); ?></span>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td></tr>
            </table>
            <div class="text-end">
                <a href="<?php echo e(route('users_edit', $user->id)); ?>" class="btn btn-success">Edit</a>
                <a href="<?php echo e(route('users_delete', $user->id)); ?>" class="btn btn-danger">Delete</a>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\WebSec230105802\WebSecService\resources\views/users/list.blade.php ENDPATH**/ ?>