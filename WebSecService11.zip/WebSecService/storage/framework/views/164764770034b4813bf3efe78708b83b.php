
<?php $__env->startSection('title', 'User Login'); ?>
<?php $__env->startSection('content'); ?>

<div class="container mt-5">
    <h2>Login</h2>

    
    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <strong>Error!</strong> <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Error!</strong> Please check your inputs.
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('do_login')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <div class="form-group mb-2">
        <label class="form-label">Email:</label>
        <input type="email" class="form-control" name="email" required>
    </div>

    <div class="form-group mb-2">
        <label class="form-label">Password:</label>
        <input type="password" class="form-control" name="password" required>
    </div>

    <button type="submit" class="btn btn-primary">Login</button>

    <div class="mt-2">
        <a href="<?php echo e(route('forgot_password')); ?>">Forgot Password?</a>
    </div>
</form>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\WebSec230105802\WebSecService\resources\views/users/login.blade.php ENDPATH**/ ?>